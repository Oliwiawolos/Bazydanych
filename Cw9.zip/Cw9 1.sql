--Zadanie 1
USE AdventureWorks2022;
WITH EMPLOYEERATECTE AS(
SELECT
e.BusinessEntityID,
e.JobTitle,
p.Rate
FROM HumanResources.Employee e
INNER JOIN HumanResources.EmployeePayHistory p
On e.BusinessEntityID=p.BusinessEntityID
)
SELECT *
INTO TempEmployeeInfos
FROM EMPLOYEERATECTE;
--Zadanie2
