--Zadanie 2
USE AdventureWorksLT2022;
WITH SALESCTE AS(
SELECT
c.CustomerID,
SUM(soh.TotalDue) AS Revenue
FROM SalesLT.SalesOrderHeader soh
JOIN SalesLT.Customer c
ON soh.CustomerID = c.CustomerID
GROUP BY c.CustomerID
)
SELECT
(c.FirstName + '' + c.LastName + '(' + c.CompanyName + ')') AS CompanyContact, s.Revenue
FROm SALESCTE s
JOIN SalesLT.Customer c ON s.CustomerID = c.CustomerID
ORDER BY s.Revenue DESC;
USE AdventureWorksLT2022;
--Zadanie 3
WITH SALESPRODUCT AS(
SELECT
pc.Name As Category,
SUM (sod.LineTotal) As SalesValue
FROM SalesLT.SalesOrderDetail sod
Join SalesLT.Product p ON sod.ProductID = p.ProductID
JOIN SalesLt.ProductCategory pc ON p.ProductCategoryID = pc.ProductCategoryID
GROUP BY pc.Name
)
SELECT
Category, 
SalesValue
FROM SALESPRODUCT
ORDER BY SalesValue DESC;